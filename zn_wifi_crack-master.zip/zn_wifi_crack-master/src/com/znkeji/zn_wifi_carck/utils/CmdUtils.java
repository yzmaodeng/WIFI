package com.znkeji.zn_wifi_carck.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: fangcheng
 * Date: 2019/3/24
 * Time: 16:21
 * Description: cmd 需要的工具类
 */
public class CmdUtils {


    public static List<String> execute(String cmd, String filePath) throws Exception {
        Process process = null;
        List<String> result = new ArrayList<String>();
        String []cmdarray = new String[3];
        cmdarray[0] = "cmd";
        cmdarray[1] = "/c";
        cmdarray[2] = "echo %cd%";
        Process process1 = Runtime.getRuntime().exec(cmdarray,null, new File(filePath));
        BufferedReader gbk1 = new BufferedReader(new InputStreamReader(process1.getInputStream(), "gbk"));
        System.out.println("当前执行的位置"+gbk1.readLine());
        System.out.println("当前运行的cmd命令--》"+cmd);
        try {
            if (filePath != null) {
                process = Runtime.getRuntime().exec(cmd, null, new File(filePath));
            } else {
                process = Runtime.getRuntime().exec(cmd);
            }
            BufferedReader bReader = new BufferedReader(new InputStreamReader(process.getInputStream(), "gbk"));
            String line = null;
            while ((line = bReader.readLine()) != null) {
                result.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

}
