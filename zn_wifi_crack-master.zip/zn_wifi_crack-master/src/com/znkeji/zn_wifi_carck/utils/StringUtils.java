package com.znkeji.zn_wifi_carck.utils;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 /**
 * Created with IntelliJ IDEA.
 * User: 臧亮
 * Date: 2020/2/16
 * Time: 20:18
 * Description:字符串工具类
 */
public class StringUtils {

    /**
     * 字符串转换成为16进制(无需Unicode编码)
     * @param str
     * @return
     */
    public static String str2HexStr(String str) {
        char[] chars = "0123456789ABCDEF".toCharArray();
        StringBuilder sb = new StringBuilder("");
        byte[] bs = str.getBytes();
        int bit;
        for (int i = 0; i < bs.length; i++) {
            bit = (bs[i] & 0x0f0) >> 4;
            sb.append(chars[bit]);
            bit = bs[i] & 0x0f;
            sb.append(chars[bit]);
            // sb.append(' ');
        }
        return sb.toString().trim();
    }

    public static void main(String[] args) {
        byte[] bytes = "Redmi".getBytes();
    }

}
